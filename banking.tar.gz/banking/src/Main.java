public class Main {

    public static void main(String args[]) {
        Details d = new Details();
        d.getInputDetails();
    }
}
