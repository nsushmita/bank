//

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class Details {
    private int accountNumber;
    private String accountName;
    private Date dob;
    private String address;
    private long adharNumber;
    private String panNumber;
    private int phoneNumber;
    private String password,emailId;
    private String accType,numberAsString;

    public String getNumberAsString() {
        return numberAsString;
    }

    public void setNumberAsString(String numberAsString) {
        this.numberAsString = numberAsString;
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAdharNumber(long adharNumber) {
        this.adharNumber = adharNumber;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }


    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Date getDob() {
        return dob;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public long getAdharNumber() {
        return adharNumber;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public String getAddress() {
        return address;
    }



    public String getPassword() {
        return password;
    }


    Details getInputDetails()
    {
        Validation v=new Validation();
        Scanner sc=new Scanner(System.in);
        String temp;
        boolean flag=false;


        Random rand=new Random();
        int number = rand.nextInt(999)+1000 ;
        setAccountNumber(number);
       do {
            System.out.println("Enter Account Name");
            temp = sc.next();
            flag=v.nameValidation(temp);
            if (flag)
            {
                setAccountName(temp);
            }
            else System.out.println("Enter valid Name");
        }while (!flag);
       do{
           System.out.println("enter account type:( 1-Savings 2-Current 3-Recurring 4-Fixed)");
           temp=sc.next();
           flag=v.typeValidation(temp);
           if(flag){
               setAccType(temp);
           }
           else System.out.println("enter valid account type");
           if(accType.equals("1")){
                numberAsString = String.valueOf(number);
               numberAsString="10SB"+numberAsString;
               setNumberAsString(numberAsString);
           }
           else if(accType.equals("2")){
               numberAsString = String.valueOf(number);
               numberAsString="10CA"+numberAsString;
               setNumberAsString(numberAsString);
           }
           else if(accType.equals("3")){
               numberAsString = String.valueOf(number);
               numberAsString="10RD"+numberAsString;
               setNumberAsString(numberAsString);
           }
           else if(accType.equals("4")){
               numberAsString = String.valueOf(number);
               numberAsString="10FD"+numberAsString;
               setNumberAsString(numberAsString);
           }


       }while(!flag);

        do {
            System.out.println("Enter pan number");
            temp = sc.next();
            flag=v.panValidation(temp);
            if (flag)
            {
                setPanNumber(temp);
            }
            else System.out.println("Enter valid pan number");
        }while (!flag);

        do {
            System.out.println("Enter email id");
            temp = sc.next();
            flag=v.emailValidation(temp);
            if (flag)
            {
                setEmailId(temp);
            }
            else System.out.println("Enter valid pan number");
        }while (!flag);


        do {
            System.out.println("Enter date of birth (yyyy-mm-dd)");
            temp = sc.next();
            flag=v.dateValidation(temp);
            if (flag)
            {
               try
               {
                   SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd");
                   Date date=format.parse(temp);
                   setDob(date);

               }
               catch(Exception e){
                System.out.println("Invalid date");
            }
            }
            else System.out.println("Invalid date");
        }while (!flag);

        System.out.println("Enter Address");
        temp=sc.next();
        setAddress(temp);

        do {
            System.out.println("Enter Phone Number");
            temp = sc.next();
            flag=v.PhoneNumberValidation(temp);
            if (flag)
            {
                setPhoneNumber(Integer.parseInt(temp));
            }
        }while (!flag);


        do {
            System.out.println("Enter Adhar Number");
            temp = sc.next();
            flag=v.AdharNumberValidation(temp);
            if (flag)
            {
                setAdharNumber(Long.parseLong(temp));
            }
        }while (!flag);

        do {
            System.out.println("Create your Password");
            temp = sc.next();

            System.out.println("Re-Enter your Password");
            String temp1 = sc.next();

            if (temp.equals(temp1)) {
                System.out.println("Password created Successfully");
                setPassword(temp);
                flag = true;
            }
            else
            {
                System.out.println("Password not Matched");
                flag = false;
            }

        }while(!flag);


        if (setInputDetails())
        {
            System.out.println("ok");
        }

        return null;
    }



    public boolean setInputDetails()
    {
        Scanner sc=new Scanner(System.in);
        String str;
        int choice;
        boolean flag=true;

        System.out.println("-----------------------------------Verify your details------------------------------");
        System.out.println("Account Number      : "+getNumberAsString());
        System.out.println("Account Name        : "+getAccountName());
        System.out.println("Pan number          : "+getPanNumber());
        System.out.println("Email id            : "+getEmailId());
        System.out.println("Address              : "+getAddress());
        System.out.println("Date Of Birth       : "+getDob());
        System.out.println("Phone Number        : "+getPhoneNumber());
        System.out.println("Adhar Number        : "+getAdharNumber());
        System.out.println("------------------------------------------------------------------------------------");
        while (flag)
        {
            System.out.println("Please Enter your Choice");
            System.out.println("1-Done 2-Cancel");
            str=sc.next();
            Validation v=new Validation();
            choice=v.choiceValidation(str);
            switch (choice)
            {
                case 1:
                    return true;
                case 2:return false;
                default:System.out.println("Invalid choice");
                    break;
            }
        }

        return false;
    }


}